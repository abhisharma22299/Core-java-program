/**
 * 
 */
/**
 * 
 */
module AtmMachine {
}